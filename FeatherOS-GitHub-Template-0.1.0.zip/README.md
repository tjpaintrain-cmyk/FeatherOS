# FeatherOS (Hypothetical) — GitHub Template

**Status:** Design/Scaffold only. This repo is a *clean-room*, academic template for a lightweight desktop OS concept named **FeatherOS**.
It provides structure, docs, sample code, and CI to help you publish and iterate. It does **not** include proprietary components or a real OS image.

> ⚖️ **Legal:** Do **not** include proprietary binaries, SDKs, headers, or code. macOS proprietary frameworks and running unmodified macOS on non‑Apple hardware are out of scope due to Apple EULA. Anticheat/DRM drivers that require Windows kernel components are not supported.

## What’s here
- `docs/` — user and developer docs (install, security, legal, porting).
- `runtime/` — clean-room compatibility layer placeholders (no proprietary code).
- `sdk/` — headers/tooling placeholders for developers.
- `samples/` — tiny, illustrative examples (C).
- `scripts/` — helper scripts, including a zip packer for release assets.
- `.github/workflows/` — CI to build zips on tag or manual dispatch.
- `artifacts/` — drop your **ISO/IMG** here if you legally built one (optional).
- `dist/` — output zips and checksums (gitignored).

## Build the distribution zips (optional)
If you have an ISO/IMG (legally built), place it into `artifacts/` named `FeatherOS-<version>.iso` (and/or `.img`). Then run:
```bash
bash scripts/build_zips.sh 0.1.0
```
The script creates:
- `dist/FeatherOS-User-0.1.0.zip`
- `dist/FeatherOS-Dev-0.1.0.zip`
- `dist/SHA256SUMS`

It includes the ISO/IMG if found; otherwise builds zips without them.

## CI Releases (GitHub Actions)
Tag the repo (e.g., `v0.1.0`) and push. The release workflow builds zips and attaches them to the GitHub Release automatically.

## License
Default: Apache-2.0 for repo contents. Adjust as you prefer.
