# feather-objc (placeholder)
Clean-room ObjC runtime & Cocoa-like framework placeholders.
