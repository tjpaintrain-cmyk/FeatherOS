# feather-win (placeholder)
Clean-room Windows ABI runtime placeholders (no proprietary code).
