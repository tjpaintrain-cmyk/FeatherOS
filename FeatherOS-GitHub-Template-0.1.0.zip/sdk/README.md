# FeatherOS SDK (placeholder)

Headers and toolchain files will live here. Keep third-party licenses intact if you add code.
