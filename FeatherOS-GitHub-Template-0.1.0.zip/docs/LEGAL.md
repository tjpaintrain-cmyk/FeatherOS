# Legal & Licensing Notes (Succinct)

- Clean-room re-implementation only. No proprietary headers, SDKs, or code.
- Do not distribute Microsoft or Apple binaries here.
- macOS unmodified binaries on non-Apple hardware are out of scope (EULA).
- Patent-sensitive codecs should be in separate, opt-in packs.
- Prefer permissive licenses (Apache-2.0 default in this repo). Add third-party notices if you include external code later.
