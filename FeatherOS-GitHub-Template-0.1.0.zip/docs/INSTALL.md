# Install / Boot

> This is a *template*. Do not distribute proprietary images.

1. Flash `FeatherOS-<version>.iso` or `.img` to a USB drive using Balena Etcher or `dd`.
2. Boot with UEFI. Enable Secure Boot only if you have signed boot chain.
3. First boot profile targets <= 500 MB idle RAM.

**Troubleshooting**
- If GPU fails, try a different kernel param or use software rendering temporarily.
