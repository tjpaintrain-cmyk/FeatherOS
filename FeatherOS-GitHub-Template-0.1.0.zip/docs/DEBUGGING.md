# Debugging & Tracing

- Use symbol packs (if generated) for `crashd` minidumps.
- eBPF-based tracing is recommended for I/O and scheduler hotspots.
- For GPU, capture Vulkan traces and compare draw-call mapping.
