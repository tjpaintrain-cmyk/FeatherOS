# Porting macOS Cocoa Applications (Ports Only)

- Rebuild your app against a clean-room Objective‑C runtime and Cocoa-like APIs.
- Metal→Vulkan translator usage must rely on legal shader translation.
- Code signing / notarization checks belonging to macOS will not be present here.
