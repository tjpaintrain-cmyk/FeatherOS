# Security and Verification

- Verify `SHA256SUMS` before installing.
- Use UEFI Secure Boot with signed kernel/initrd if supported.
- Updates should be signed (example: Ed25519) and verified pre-apply.
