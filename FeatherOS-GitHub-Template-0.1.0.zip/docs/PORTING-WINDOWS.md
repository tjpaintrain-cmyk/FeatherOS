# Porting Windows Applications (Clean-Room)

- Prefer open .NET runtimes for managed apps.
- Use the DX→Vulkan shim libraries provided by `runtime/` (placeholders).
- Avoid private/undocumented APIs. Behavior derived via black-box testing only.
