# Compatibility (High-Level, Clean-Room Only)

- **Windows apps**: via clean-room Win32/Win64 ABI, Direct3D→Vulkan translators, COM basics, .NET open runtimes.
- **macOS apps**: **ports only** (recompiled) against clean-room ObjC runtime and Cocoa-like frameworks.
- **PROPRIETARY-BLOCKER**: anticheat/DRM requiring kernel drivers; macOS proprietary frameworks/binaries; Apple EULA constraints.

See repository root README for scope.
