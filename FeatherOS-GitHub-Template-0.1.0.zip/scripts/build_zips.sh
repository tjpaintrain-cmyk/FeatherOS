#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <version>" >&2
  exit 1
fi

VERSION="$1"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="$ROOT/dist"
ART="$ROOT/artifacts"

mkdir -p "$DIST"

USER_ZIP="$DIST/FeatherOS-User-$VERSION.zip"
DEV_ZIP="$DIST/FeatherOS-Dev-$VERSION.zip"
SUMS="$DIST/SHA256SUMS"

# Prepare temp dirs
TMP_USER="$(mktemp -d)"
TMP_DEV="$(mktemp -d)"
trap 'rm -rf "$TMP_USER" "$TMP_DEV"' EXIT

# Common docs
mkdir -p "$TMP_USER/docs" "$TMP_DEV/docs"
cp -r "$ROOT/docs/." "$TMP_USER/docs/"
cp -r "$ROOT/docs/." "$TMP_DEV/docs/"

# Runtime
mkdir -p "$TMP_USER/runtime" "$TMP_DEV/runtime"
cp -r "$ROOT/runtime/." "$TMP_USER/runtime/"
cp -r "$ROOT/runtime/." "$TMP_DEV/runtime/"

# Tools (user-friendly subset)
mkdir -p "$TMP_USER/tools"
cat > "$TMP_USER/tools/README.txt" <<EOF
Tools placeholder: 'feather-update', 'feather-run', 'feather-dump' would live here.
EOF

# Dev SDK & samples
mkdir -p "$TMP_DEV/sdk" "$TMP_DEV/samples"
cp -r "$ROOT/sdk/." "$TMP_DEV/sdk/" || true
cp -r "$ROOT/samples/." "$TMP_DEV/samples/" || true

# Include ISO/IMG if present
if [[ -f "$ART/FeatherOS-$VERSION.iso" ]]; then
  cp "$ART/FeatherOS-$VERSION.iso" "$TMP_USER/"
  cp "$ART/FeatherOS-$VERSION.iso" "$TMP_DEV/"
fi
if [[ -f "$ART/FeatherOS-$VERSION.img" ]]; then
  cp "$ART/FeatherOS-$VERSION.img" "$TMP_USER/"
  cp "$ART/FeatherOS-$VERSION.img" "$TMP_DEV/"
fi

# Checksums inside each package (if ISOs included)
if [[ -f "$TMP_USER/FeatherOS-$VERSION.iso" || -f "$TMP_USER/FeatherOS-$VERSION.img" ]]; then
  (cd "$TMP_USER" && \
    { command -v sha256sum >/dev/null && sha256sum FeatherOS-$VERSION.* || shasum -a 256 FeatherOS-$VERSION.*; } > SHA256SUMS)
  cp "$TMP_USER/SHA256SUMS" "$TMP_DEV/SHA256SUMS"
fi

# Top-level docs
cp "$ROOT/README.md" "$TMP_USER/"
cp "$ROOT/README.md" "$TMP_DEV/"
cp "$ROOT/LICENSE" "$TMP_USER/"
cp "$ROOT/LICENSE" "$TMP_DEV/"

# Zip them
( cd "$TMP_USER" && zip -r9 "$USER_ZIP" . >/dev/null )
( cd "$TMP_DEV"  && zip -r9 "$DEV_ZIP"  . >/dev/null )

# Global checksums file
: > "$SUMS"
for f in "$USER_ZIP" "$DEV_ZIP"; do
  if command -v sha256sum >/dev/null; then
    sha256sum "$f" >> "$SUMS"
  else
    shasum -a 256 "$f" >> "$SUMS"
  fi
done

echo "Built: $USER_ZIP"
echo "Built: $DEV_ZIP"
echo "Checksums: $SUMS"
