// SPDX-License-Identifier: Apache-2.0
// Minimal Win32-style console "Hello Feather"
#include <stdio.h>
int main(void){
    printf("Hello Feather (Win32-style)!\n");
    return 0;
}
