// SPDX-License-Identifier: Apache-2.0
// Placeholder: a real Wayland example would link to wayland-client.
#include <stdio.h>
int main(void){
    printf("Wayland 'hello' placeholder.\n");
    return 0;
}
