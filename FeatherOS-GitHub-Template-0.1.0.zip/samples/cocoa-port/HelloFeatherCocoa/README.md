This is a placeholder for a Cocoa-port sample built against clean-room ObjC/Cocoa-like APIs.
